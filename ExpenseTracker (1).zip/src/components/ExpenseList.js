
import React, { useEffect, useState } from 'react';
import { db } from '../firebase';
import { collection, onSnapshot } from 'firebase/firestore';

export default function ExpenseList(){
  const [list,setList] = useState([]);

  useEffect(()=>{
    return onSnapshot(collection(db,"expenses"), snap=>{
      setList(snap.docs.map(d=>({id:d.id,...d.data()})))
    })
  },[]);

  return (
    <ul>
      {list.map(e=>(
        <li key={e.id}>{e.desc} - ₹{e.amount}</li>
      ))}
    </ul>
  );
}
