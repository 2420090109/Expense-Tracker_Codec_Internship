
import React, { useState } from 'react';
import { db } from '../firebase';
import { addDoc, collection } from 'firebase/firestore';

export default function ExpenseForm(){
  const [amount,setAmount] = useState('');
  const [desc,setDesc] = useState('');

  const add = async ()=>{
    await addDoc(collection(db,"expenses"),{
      amount: Number(amount),
      desc,
      created: Date.now()
    });
    setAmount(''); setDesc('');
  };

  return (
    <div>
      <input placeholder='Amount' value={amount} onChange={e=>setAmount(e.target.value)} />
      <input placeholder='Description' value={desc} onChange={e=>setDesc(e.target.value)} />
      <button onClick={add}>Add</button>
    </div>
  );
}
